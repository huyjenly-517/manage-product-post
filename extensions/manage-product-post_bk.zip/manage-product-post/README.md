# Product Quickview Extension

Một extension mạnh mẽ cho Shopify để thêm tính năng xem nhanh sản phẩm (quickview) vào theme của bạn.

## ✨ Tính năng

- **Modal Quickview** - Xem chi tiết sản phẩm mà không cần rời khỏi trang
- **Hình ảnh sản phẩm** - Hỗ trợ nhiều hình ảnh với thumbnails
- **Chọn biến thể** - Dễ dàng chọn size, màu sắc, v.v.
- **Thêm vào giỏ hàng** - Trực tiếp từ quickview modal
- **Responsive design** - Hoạt động tốt trên mọi thiết bị
- **Tùy chỉnh dễ dàng** - Thông qua theme customizer
- **Tích hợp hoàn hảo** - Với Shopify cart và theme

## 🚀 Cài đặt

### 1. Deploy Extension

```bash
# Từ thư mục gốc của app
shopify app deploy
```

### 2. Cài đặt vào Theme

1. Vào **Shopify Admin** → **Online Store** → **Themes**
2. Click **Customize** trên theme bạn muốn sử dụng
3. Chọn **Product page** hoặc **Collection page**
4. Click **Add block** → Tìm **Product Quickview**
5. Thêm block vào vị trí mong muốn

## 📖 Cách sử dụng

### Sử dụng Snippet (Đơn giản)

Thêm vào product card hoặc product grid:

```liquid
{% render 'product-quickview' %}
```

### Sử dụng Block (Khuyến nghị)

Thêm block **Product Quickview** thông qua theme customizer để có thể tùy chỉnh dễ dàng.

### Sử dụng JavaScript (Nâng cao)

```javascript
// Mở quickview cho sản phẩm
openProductQuickview(productData);

// Hoặc sử dụng trực tiếp
productQuickview.open(productData);
```

## 🎨 Tùy chỉnh

### Button Styles

- **Primary** - Nút chính (màu xanh)
- **Secondary** - Nút phụ (màu xám)
- **Outline** - Nút viền (không màu nền)
- **Icon Only** - Chỉ hiển thị icon

### Button Sizes

- **Small** - Nhỏ
- **Medium** - Vừa (mặc định)
- **Large** - Lớn

### Button Positions

- **Top Left** - Góc trên trái
- **Top Right** - Góc trên phải
- **Bottom Left** - Góc dưới trái
- **Bottom Right** - Góc dưới phải (mặc định)
- **Center** - Giữa

### Custom Colors

- **Custom Button Color** - Màu nền tùy chỉnh
- **Custom Text Color** - Màu chữ tùy chỉnh

## 🔧 Cấu hình

### Trong Theme Customizer

1. **Quickview Button Settings**
   - Show Quickview Button
   - Button Text
   - Button Style
   - Button Size
   - Show Icon in Button
   - Button Icon
   - Custom Button Color
   - Custom Text Color

2. **Position Settings**
   - Button Position

3. **Additional Options**
   - Show Quickview Indicator Icon
   - Quickview Indicator Icon

## 📱 Responsive Design

Extension tự động thích ứng với mọi kích thước màn hình:

- **Desktop** - Layout 2 cột (hình ảnh + thông tin)
- **Tablet** - Layout 2 cột với padding nhỏ hơn
- **Mobile** - Layout 1 cột (hình ảnh trên, thông tin dưới)

## 🎯 Sử dụng trong Theme

### Product Card

```liquid
<div class="product-card">
  <img src="{{ product.featured_image | img_url: '300x300' }}" alt="{{ product.title }}">
  <h3>{{ product.title }}</h3>
  <p>{{ product.price | money }}</p>
  
  <!-- Thêm quickview button -->
  {% render 'product-quickview' %}
</div>
```

### Product Grid

```liquid
<div class="product-grid">
  {% for product in collection.products %}
    <div class="product-item">
      <!-- Product content -->
      
      <!-- Quickview button -->
      {% render 'product-quickview' %}
    </div>
  {% endfor %}
</div>
```

### Custom Product Template

```liquid
<div class="custom-product-layout">
  <!-- Product images -->
  <div class="product-images">
    <!-- ... -->
  </div>
  
  <!-- Product info -->
  <div class="product-info">
    <!-- ... -->
    
    <!-- Quickview button -->
    {% render 'product-quickview' %}
  </div>
</div>
```

## 🚀 API Reference

### Methods

#### `openProductQuickview(product)`
Mở quickview modal cho sản phẩm

```javascript
openProductQuickview({
  id: 123456789,
  title: "Product Name",
  price: 29900,
  compare_at_price: 39900,
  description: "Product description...",
  vendor: "Brand Name",
  product_type: "Category",
  tags: ["tag1", "tag2"],
  images: [
    { src: "image1.jpg", alt: "Image 1" },
    { src: "image2.jpg", alt: "Image 2" }
  ],
  variants: [
    { id: 123, title: "Small", price: 29900 },
    { id: 124, title: "Medium", price: 29900 },
    { id: 125, title: "Large", price: 29900 }
  ]
});
```

#### `productQuickview.open(product)`
Mở quickview modal (tương tự `openProductQuickview`)

#### `productQuickview.close()`
Đóng quickview modal

### Events

#### `quickview:opened`
Được trigger khi quickview mở

```javascript
document.addEventListener('quickview:opened', function(event) {
  console.log('Quickview opened for:', event.detail.product);
  // Thêm analytics tracking
});
```

#### `quickview:closed`
Được trigger khi quickview đóng

```javascript
document.addEventListener('quickview:closed', function(event) {
  console.log('Quickview closed');
  // Thêm analytics tracking
});
```

#### `cart:updated`
Được trigger khi thêm sản phẩm vào giỏ hàng

```javascript
document.addEventListener('cart:updated', function(event) {
  console.log('Cart updated:', event.detail.item);
  // Cập nhật cart count, mini cart, etc.
});
```

## 🎨 CSS Customization

### Override Default Styles

```css
/* Tùy chỉnh button style */
.quickview-btn {
  background: linear-gradient(45deg, #ff6b6b, #ee5a24);
  border-radius: 25px;
  box-shadow: 0 4px 15px rgba(255, 107, 107, 0.3);
}

/* Tùy chỉnh modal style */
.quickview-content {
  border-radius: 20px;
  box-shadow: 0 25px 50px rgba(0, 0, 0, 0.4);
}

/* Tùy chỉnh price style */
.current-price {
  color: #ff6b6b;
  font-size: 32px;
}
```

### Position Classes

```css
/* Top Left */
.quickview-position-top-left {
  position: absolute;
  top: 10px;
  left: 10px;
}

/* Top Right */
.quickview-position-top-right {
  position: absolute;
  top: 10px;
  right: 10px;
}

/* Bottom Left */
.quickview-position-bottom-left {
  position: absolute;
  bottom: 10px;
  left: 10px;
}

/* Bottom Right */
.quickview-position-bottom-right {
  position: absolute;
  bottom: 10px;
  right: 10px;
}

/* Center */
.quickview-position-center {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}
```

## 🔍 Troubleshooting

### Quickview không hiển thị

1. Kiểm tra console có lỗi JavaScript không
2. Đảm bảo CSS và JS files được load
3. Kiểm tra `product` object có đúng format không

### Button không hoạt động

1. Kiểm tra `onclick` event có được trigger không
2. Đảm bảo `productQuickview` object đã được khởi tạo
3. Kiểm tra `product` data có đầy đủ không

### Modal không đóng

1. Kiểm tra `close()` method có được gọi không
2. Đảm bảo CSS `display: none` được áp dụng
3. Kiểm tra event listeners có hoạt động không

## 📞 Hỗ trợ

Nếu gặp vấn đề hoặc cần hỗ trợ:

1. Kiểm tra **Console** trong Developer Tools
2. Xem **Network** tab để đảm bảo files được load
3. Kiểm tra **Elements** tab để xem HTML structure
4. Liên hệ support team

## 🎉 Kết luận

Product Quickview Extension cung cấp một giải pháp hoàn chỉnh để thêm tính năng quickview vào Shopify theme của bạn. Với giao diện đẹp, responsive design và khả năng tùy chỉnh cao, extension này sẽ giúp cải thiện trải nghiệm mua sắm của khách hàng và tăng tỷ lệ chuyển đổi.

---

**Lưu ý:** Extension này hoạt động tốt nhất với Shopify themes hiện đại và cần JavaScript được enable trên trình duyệt của khách hàng. 