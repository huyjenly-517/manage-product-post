class ProductQuickview {
  constructor() {
    this.isOpen = false;
    this.currentProduct = null;
    this.init();
  }

  init() {
    this.createModal();
    this.bindEvents();
  }

  createModal() {
    const modalHTML = `
      <div id="product-quickview-modal" class="quickview-modal" style="display: none;">
        <div class="quickview-overlay"></div>
        <div class="quickview-content">
          <div class="quickview-header">
            <h2 class="quickview-title"></h2>
            <button class="quickview-close" onclick="productQuickview.close()">✕</button>
          </div>
          
          <div class="quickview-body">
            <div class="quickview-images">
              <div class="main-image-container">
                <img class="main-image" src="" alt="">
              </div>
              <div class="image-thumbnails"></div>
            </div>
            
            <div class="quickview-info">
              <div class="product-price">
                <span class="current-price"></span>
                <span class="compare-price" style="display: none;"></span>
              </div>
              
              <div class="product-description"></div>
              
              <div class="product-variants" style="display: none;">
                <h4>Biến thể:</h4>
                <div class="variant-options"></div>
              </div>
              
              <div class="product-quantity">
                <label>Số lượng:</label>
                <div class="quantity-controls">
                  <button class="quantity-btn minus" onclick="productQuickview.changeQuantity(-1)">-</button>
                  <input type="number" class="quantity-input" value="1" min="1" max="99">
                  <button class="quantity-btn plus" onclick="productQuickview.changeQuantity(1)">+</button>
                </div>
              </div>
              
              <button class="add-to-cart-btn" onclick="productQuickview.addToCart()">
                Thêm vào giỏ hàng
              </button>
              
              <div class="product-meta">
                <div class="meta-item vendor" style="display: none;">
                  <span class="meta-label">Thương hiệu:</span>
                  <span class="meta-value"></span>
                </div>
                <div class="meta-item product-type" style="display: none;">
                  <span class="meta-label">Loại:</span>
                  <span class="meta-value"></span>
                </div>
                <div class="meta-item tags" style="display: none;">
                  <span class="meta-label">Tags:</span>
                  <div class="tags"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHTML);
  }

  bindEvents() {
    // Close modal when clicking overlay
    document.addEventListener('click', (e) => {
      if (e.target.classList.contains('quickview-overlay')) {
        this.close();
      }
    });

    // Close modal with Escape key
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && this.isOpen) {
        this.close();
      }
    });
  }

  open(product) {
    this.currentProduct = product;
    this.isOpen = true;
    
    // Populate modal with product data
    this.populateModal(product);
    
    // Show modal
    const modal = document.getElementById('product-quickview-modal');
    modal.style.display = 'block';
    document.body.style.overflow = 'hidden';
    
    // Trigger open event
    this.triggerEvent('quickview:opened', { product });
  }

  close() {
    this.isOpen = false;
    this.currentProduct = null;
    
    // Hide modal
    const modal = document.getElementById('product-quickview-modal');
    modal.style.display = 'none';
    document.body.style.overflow = 'unset';
    
    // Trigger close event
    this.triggerEvent('quickview:closed');
  }

  populateModal(product) {
    // Title
    document.querySelector('.quickview-title').textContent = product.title;
    
    // Main image
    const mainImage = document.querySelector('.main-image');
    mainImage.src = product.featured_image || product.images[0]?.src || '';
    mainImage.alt = product.title;
    
    // Price
    const currentPrice = document.querySelector('.current-price');
    currentPrice.textContent = this.formatPrice(product.price);
    
    // Compare price
    const comparePrice = document.querySelector('.compare-price');
    if (product.compare_at_price && product.compare_at_price > product.price) {
      comparePrice.textContent = this.formatPrice(product.compare_at_price);
      comparePrice.style.display = 'inline';
    } else {
      comparePrice.style.display = 'none';
    }
    
    // Description
    const description = document.querySelector('.product-description');
    if (product.description) {
      description.innerHTML = `<p>${product.description}</p>`;
    } else {
      description.innerHTML = '';
    }
    
    // Variants
    this.populateVariants(product.variants);
    
    // Meta information
    this.populateMeta(product);
    
    // Image thumbnails
    this.populateThumbnails(product.images);
  }

  populateVariants(variants) {
    const variantsContainer = document.querySelector('.product-variants');
    const optionsContainer = document.querySelector('.variant-options');
    
    if (variants && variants.length > 1) {
      variantsContainer.style.display = 'block';
      optionsContainer.innerHTML = variants.map(variant => `
        <button class="variant-option" data-variant-id="${variant.id}">
          ${variant.title}
        </button>
      `).join('');
      
      // Select first variant by default
      this.selectVariant(variants[0]);
      
      // Bind variant selection events
      optionsContainer.addEventListener('click', (e) => {
        if (e.target.classList.contains('variant-option')) {
          const variantId = e.target.dataset.variantId;
          const variant = variants.find(v => v.id === variantId);
          if (variant) {
            this.selectVariant(variant);
          }
        }
      });
    } else {
      variantsContainer.style.display = 'none';
    }
  }

  selectVariant(variant) {
    // Update selected variant
    this.currentProduct.selectedVariant = variant;
    
    // Update price
    const currentPrice = document.querySelector('.current-price');
    currentPrice.textContent = this.formatPrice(variant.price);
    
    // Update compare price
    const comparePrice = document.querySelector('.compare-price');
    if (variant.compare_at_price && variant.compare_at_price > variant.price) {
      comparePrice.textContent = this.formatPrice(variant.compare_at_price);
      comparePrice.style.display = 'inline';
    } else {
      comparePrice.style.display = 'none';
    }
    
    // Update main image if variant has image
    if (variant.featured_image) {
      const mainImage = document.querySelector('.main-image');
      mainImage.src = variant.featured_image;
    }
    
    // Update variant buttons
    document.querySelectorAll('.variant-option').forEach(btn => {
      btn.classList.remove('selected');
      if (btn.dataset.variantId === variant.id) {
        btn.classList.add('selected');
      }
    });
  }

  populateMeta(product) {
    // Vendor
    const vendorItem = document.querySelector('.meta-item.vendor');
    if (product.vendor) {
      vendorItem.querySelector('.meta-value').textContent = product.vendor;
      vendorItem.style.display = 'block';
    } else {
      vendorItem.style.display = 'none';
    }
    
    // Product type
    const typeItem = document.querySelector('.meta-item.product-type');
    if (product.product_type) {
      typeItem.querySelector('.meta-value').textContent = product.product_type;
      typeItem.style.display = 'block';
    } else {
      typeItem.style.display = 'none';
    }
    
    // Tags
    const tagsItem = document.querySelector('.meta-item.tags');
    if (product.tags && product.tags.length > 0) {
      const tagsContainer = tagsItem.querySelector('.tags');
      tagsContainer.innerHTML = product.tags.map(tag => 
        `<span class="tag">${tag}</span>`
      ).join('');
      tagsItem.style.display = 'block';
    } else {
      tagsItem.style.display = 'none';
    }
  }

  populateThumbnails(images) {
    const thumbnailsContainer = document.querySelector('.image-thumbnails');
    
    if (images && images.length > 1) {
      thumbnailsContainer.innerHTML = images.map((image, index) => `
        <img 
          src="${image.src}" 
          alt="${image.alt || ''}" 
          class="thumbnail ${index === 0 ? 'active' : ''}"
          onclick="productQuickview.selectImage(${index})"
        >
      `).join('');
    } else {
      thumbnailsContainer.innerHTML = '';
    }
  }

  selectImage(index) {
    const images = this.currentProduct.images;
    if (images && images[index]) {
      const mainImage = document.querySelector('.main-image');
      mainImage.src = images[index].src;
      
      // Update thumbnail selection
      document.querySelectorAll('.thumbnail').forEach((thumb, i) => {
        thumb.classList.toggle('active', i === index);
      });
    }
  }

  changeQuantity(delta) {
    const input = document.querySelector('.quantity-input');
    let newQuantity = parseInt(input.value) + delta;
    
    if (newQuantity >= 1 && newQuantity <= 99) {
      input.value = newQuantity;
    }
  }

  async addToCart() {
    if (!this.currentProduct) return;
    
    const variant = this.currentProduct.selectedVariant || this.currentProduct.variants[0];
    const quantity = parseInt(document.querySelector('.quantity-input').value) || 1;
    
    if (!variant) {
      alert('Vui lòng chọn biến thể sản phẩm');
      return;
    }
    
    try {
      // Add to cart using Shopify AJAX API
      const response = await fetch('/cart/add.js', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          items: [{
            id: variant.id,
            quantity: quantity
          }]
        })
      });
      
      if (response.ok) {
        const result = await response.json();
        alert('Đã thêm vào giỏ hàng!');
        this.close();
        
        // Trigger cart update event
        this.triggerEvent('cart:updated', { item: result });
        
        // Update cart count if cart count element exists
        this.updateCartCount();
      } else {
        throw new Error('Failed to add to cart');
      }
    } catch (error) {
      console.error('Lỗi khi thêm vào giỏ hàng:', error);
      alert('Có lỗi xảy ra khi thêm vào giỏ hàng');
    }
  }

  updateCartCount() {
    // Try to find cart count element and update it
    const cartCountElements = document.querySelectorAll('[data-cart-count], .cart-count, #cart-count');
    if (cartCountElements.length > 0) {
      // Fetch current cart count
      fetch('/cart.js')
        .then(response => response.json())
        .then(cart => {
          cartCountElements.forEach(element => {
            element.textContent = cart.item_count;
          });
        })
        .catch(console.error);
    }
  }

  formatPrice(price) {
    return new Intl.NumberFormat('vi-VN', {
      style: 'currency',
      currency: 'VND'
    }).format(price / 100); // Shopify prices are in cents
  }

  triggerEvent(eventName, data = {}) {
    const event = new CustomEvent(eventName, { detail: data });
    document.dispatchEvent(event);
  }
}

// Initialize Product Quickview
const productQuickview = new ProductQuickview();

// Export for global use
window.productQuickview = productQuickview;

// Helper function to open quickview from theme
window.openProductQuickview = function(product) {
  productQuickview.open(product);
}; 